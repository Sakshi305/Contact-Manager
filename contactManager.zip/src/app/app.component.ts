import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'contactManager';
  displayedColumns: string[] = ['action', 'firstName', 'lastName', 'email', 'phoneNumber', 'status'];
  dataSource: MatTableDataSource<contactDetail>;;
  contactForm: FormGroup;
  formView = false;
  contactList = ELEMENT_DATA;
  actionType = 'add';
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.contactList);
    this.createForm();
  }

  createForm() {
    this.contactForm = this.fb.group({
      id: [0],
      firstName: ['', [Validators.required, Validators.pattern('[a-zA-Z]*')]],
      lastName: ['', [Validators.required, Validators.pattern('[a-zA-Z]*')]],
      email: ['', [Validators.required, Validators.pattern('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$')]],
      phoneNumber: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      status: [{ value: 'ACTIVE', disabled: true }],
    })
  }

  getErrorMessage(field, type) {
    if (type === 'required') {
      return field + ' is required.'
    } else if (type === 'pattern') {
      if (field === 'email') {
        return field + ' is not in valid Format.'
      } else if (field === 'First Name' || field === 'Last Name') {
        return field + ' should contain alphabets only.'
      } else if (field === 'Phone Number') {
        return field + ' should contain 10 numeric digits only.'
      }
    } else {
      if (field === 'Phone Number') {
        return field + ' should contain 10 digits.'
      }
    }

  }

  addContact() {
    this.formView = true;
  }

  saveContact() {
    if (this.contactForm.getRawValue().id !== 0) {
      this.contactList = this.contactList.filter(contact => contact.id !== this.contactForm.getRawValue().id);
    } else {
      this.contactForm.get('id').setValue(this.contactList.length);
    }
    this.contactList.push(this.contactForm.getRawValue());
    this.dataSource = new MatTableDataSource(this.contactList);
    this.formView = false;
    this.contactForm.reset();
  }

  inactiveContact(element) {
    element.status = 'INACTIVE';
  }

  activeContact(element){
    element.status = 'ACTIVE';
  }

  editContact(element) {
    this.contactForm.setValue(element);
    this.formView = true;
  }

}

export interface contactDetail {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: number;
  status: string;

}

const ELEMENT_DATA: contactDetail[] = [
  { id: 1, firstName: 'ABCD', lastName: 'Last', email: 'abcd@test.com', phoneNumber: 1234567890, status: 'ACTIVE', },
  { id: 1, firstName: 'XY', lastName: 'Last', email: 'xy@test.com', phoneNumber: 1987654321, status: 'ACTIVE', },
];
